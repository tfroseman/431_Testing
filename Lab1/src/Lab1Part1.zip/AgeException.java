/**
 * Lab1.PACKAGE_NAME
 * thomasroseman on 1/12/16
 */
public class AgeException extends Exception {
    public AgeException(String message) {
        super(message);
    }
}
