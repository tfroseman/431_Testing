package Part2;

/**
 * Lab1.PACKAGE_NAME
 * thomasroseman on 1/12/16
 */
public class NameException extends Exception {
    public NameException(String message) {
        super(message);
    }
}
