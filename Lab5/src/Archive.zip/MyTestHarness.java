/**
 * Lab5.PACKAGE_NAME
 * thomasroseman on 2/9/16
 */
public abstract class MyTestHarness extends TestHarness {

}
